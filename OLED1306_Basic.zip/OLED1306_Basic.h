/*   Modified for OLED display.  See the cpp file for some notes.

  OLED1306_Basic.h
  OLED1305_Basic.h
  LDC5110_Basic.h  - Arduino/chipKit library support for Nokia 5110 compatible LCDs
  Copyright (C)2015 Rinky-Dink Electronics, Henning Karlsen. All right reserved
  
  Basic functionality of this library are based on the demo-code provided by
  ITead studio. You can find the latest version of the library at
  http://www.RinkyDinkElectronics.com/

  This library has been made to make it easy to use the basic functions of
  the Nokia 5110 LCD module on an Arduino or a chipKit.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the CC BY-NC-SA 3.0 license.
  Please see the included documents for further information.

  Commercial use of this library requires you to buy a license that
  will allow commercial use. This includes using the library,
  modified or not, as a tool to sell products.

  The license applies to all part of the library including the 
  examples and tools supplied with the library.
*/

#ifndef OLED1306_Basic_h
#define OLED1306_Basic_h

#define LEFT 0
#define RIGHT 9999
#define CENTER 9998

#define LCD_COMMAND 0
#define LCD_DATA 1
#define LCD_END  2

// OLED commands
// SSD1306 Commandset
// ------------------
// Fundamental Commands
#define SSD1306_SET_CONTRAST_CONTROL					0x81
#define SSD1306_DISPLAY_ALL_ON_RESUME					0xA4
#define SSD1306_DISPLAY_ALL_ON							0xA5
#define SSD1306_NORMAL_DISPLAY							0xA6
#define SSD1306_INVERT_DISPLAY							0xA7
#define SSD1306_DISPLAY_OFF								0xAE
#define SSD1306_DISPLAY_ON								0xAF
#define SSD1306_NOP										0xE3
// Scrolling Commands
#define SSD1306_HORIZONTAL_SCROLL_RIGHT					0x26
#define SSD1306_HORIZONTAL_SCROLL_LEFT					0x27
#define SSD1306_HORIZONTAL_SCROLL_VERTICAL_AND_RIGHT	0x29
#define SSD1306_HORIZONTAL_SCROLL_VERTICAL_AND_LEFT		0x2A
#define SSD1306_DEACTIVATE_SCROLL						0x2E
#define SSD1306_ACTIVATE_SCROLL							0x2F
#define SSD1306_SET_VERTICAL_SCROLL_AREA				0xA3
// Addressing Setting Commands
#define SSD1306_SET_LOWER_COLUMN						0x00
#define SSD1306_SET_HIGHER_COLUMN						0x10
#define SSD1306_MEMORY_ADDR_MODE						0x20
#define SSD1306_SET_COLUMN_ADDR							0x21
#define SSD1306_SET_PAGE_ADDR							0x22
// Hardware Configuration Commands
#define SSD1306_SET_START_LINE							0x40
#define SSD1306_SET_SEGMENT_REMAP						0xA0
#define SSD1306_SET_MULTIPLEX_RATIO						0xA8
#define SSD1306_COM_SCAN_DIR_INC						0xC0
#define SSD1306_COM_SCAN_DIR_DEC						0xC8
#define SSD1306_SET_DISPLAY_OFFSET						0xD3
#define SSD1306_SET_COM_PINS							0xDA
#define SSD1306_CHARGE_PUMP								0x8D
// Timing & Driving Scheme Setting Commands
#define SSD1306_SET_DISPLAY_CLOCK_DIV_RATIO				0xD5
#define SSD1306_SET_PRECHARGE_PERIOD					0xD9
#define SSD1306_SET_VCOM_DESELECT						0xDB


//#define SSD1305_SETLOWCOLUMN 0x00
//#define SSD1305_SETHIGHCOLUMN 0x10
//#define SSD1305_MEMORYMODE 0x20
//#define SSD1305_SETCOLADDR 0x21
//#define SSD1305_SETPAGEADDR 0x22
//#define SSD1305_SETSTARTLINE 0x40

//#define SSD1305_SETCONTRAST 0x81
//#define SSD1305_SETBRIGHTNESS 0x82

//#define SSD1305_SETLUT 0x91

//#define SSD1305_SEGREMAP 0xA0
//#define SSD1305_DISPLAYALLON_RESUME 0xA4
//#define SSD1305_DISPLAYALLON 0xA5
//#define SSD1305_NORMALDISPLAY 0xA6
//#define SSD1305_INVERTDISPLAY 0xA7
//#define SSD1305_SETMULTIPLEX 0xA8
//#define SSD1305_DISPLAYDIM 0xAC
//#define SSD1305_MASTERCONFIG 0xAD
//#define SSD1305_DISPLAYOFF 0xAE
//#define SSD1305_DISPLAYON 0xAF

//#define SSD1305_SETPAGESTART 0xB0

//#define SSD1305_COMSCANINC 0xC0
//#define SSD1305_COMSCANDEC 0xC8
//#define SSD1305_SETDISPLAYOFFSET 0xD3
//#define SSD1305_SETDISPLAYCLOCKDIV 0xD5
//#define SSD1305_SETAREACOLOR 0xD8
//#define SSD1305_SETPRECHARGE 0xD9
//#define SSD1305_SETCOMPINS 0xDA
//#define SSD1305_SETVCOMLEVEL 0xDB



// PCD8544 Commandset
// ------------------
// General commands
//#define PCD8544_POWERDOWN			0x04
//#define PCD8544_ENTRYMODE			0x02
//#define PCD8544_EXTENDEDINSTRUCTION	0x01
//#define PCD8544_DISPLAYBLANK		0x00
//#define PCD8544_DISPLAYNORMAL		0x04
//#define PCD8544_DISPLAYALLON		0x01
//#define PCD8544_DISPLAYINVERTED		0x05
// Normal instruction set
//#define PCD8544_FUNCTIONSET			0x20
//#define PCD8544_DISPLAYCONTROL		0x08
//#define PCD8544_SETYADDR			0x40
//#define PCD8544_SETXADDR			0x80
// Extended instruction set
//#define PCD8544_SETTEMP				0x04
//#define PCD8544_SETBIAS				0x10
//#define PCD8544_SETVOP				0x80
// Display presets
//#define LCD_BIAS					0x03	// Range: 0-7 (0x00-0x07)
//#define LCD_TEMP					0x02	// Range: 0-3 (0x00-0x03)
#define LCD_CONTRAST				0x32	// Range: 0-127 (0x00-0x7F)

#if defined(__AVR__)
	#include "Arduino.h"
	#include "hardware/avr/HW_AVR_defines.h"
#elif defined(__PIC32MX__)
	#include "WProgram.h"
	#include "hardware/pic32/HW_PIC32_defines.h"
#elif defined(__arm__)
	#include "Arduino.h"
	#include "hardware/arm/HW_ARM_defines.h"
#endif

struct _current_font
{
	uint8_t* font;
	uint8_t x_size;
	uint8_t y_size;
	uint8_t offset;
	uint8_t numchars;
	uint8_t inverted;
};

class OLED1306
{
	public:
		OLED1306();
		void	InitLCD();
		//void	setContrast(int contrast);
		//void	enableSleep();
		//void	disableSleep();
		void	clrScr();
		void	clrRow(int row, int start_x = 0, int end_x = 131);
		void	invert(bool mode);
		void	invertText(bool mode);
		void	print(char *st, int x, int y);
		void	print(String st, int x, int y);
		void	printNumI(long num, int x, int y, int length=0, char filler=' ');
		void	printNumF(double num, byte dec, int x, int y, char divider='.', int length=0, char filler=' ');
		void	setFont(uint8_t* font);
		void	drawBitmap(int x, int y, bitmapdatatype bitmap, int sx, int sy);
           //void viewPage( int page );
           void gotoRowCol( int row, int col );
           void write( unsigned char dat, int count = 1 );
           void putch( char dat );
           void puts( char *p );

	protected:
		regtype			*P_SCK, *P_MOSI, *P_DC, *P_RST, *P_CS;
		regsize			B_SCK, B_MOSI, B_DC, B_RST, B_CS;
		uint8_t			SCK_Pin, RST_Pin;			// Needed for for faster MCUs
		_current_font	cfont;
		boolean			_sleep;
		int				_contrast;

		void	_LCD_Write(unsigned char data, unsigned char mode);
		void	_print_char(unsigned char c, int x, int row);
		void	_convert_float(char *buf, double num, int width, byte prec);

};

#endif