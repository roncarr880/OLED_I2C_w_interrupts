/*

  RWC notes:
  Modified again for an OLED I2C display with a 1306 controller.   Display size 128 by 64.
  The main advantage of this effort vs OLED_I2C library also by Rinky Dink Electronics is this does not
  use a buffer memory and so will be useful for processors with small amounts of RAM.


  K1URC
  MODIFIED FOR AN OLED DISPLAY with 1305 controller.
    Tested with a 128 by 32 display.
    Mount display upside down( pins at top ).
    Display memory is 132 by 8 rows.
       We see only 128 columns
       With a 128 by 4 row display, the controller still has ram for 8 lines.
       With 128x32 4 row display at default setting we see rows 4-7 of 0-7.
          So unless something is done we don't see anything.
          Setting a page write offset of 32 and calling that page 0, rows 0 to 3.
            User program writes rows 0 to 7.
            Call viewPage( 1 ) to see the remapped rows 4-7.
            For a 128 by 64 display, change the init to have a page offset of zero.
          I think with this setup one could do page flipping animation.
  Added functions:
     viewPage   -  allow one to see the normally hidden part of the screen
     gotoRowCol -  set screen position for the write and putch functions
     write      -  write one or more single bytes
     putch      -  print a single character
     puts       -  print a character array starting at the current page/column
 
  LCD5110_Basic.cpp - Arduino/chipKit library support for Nokia 5110 compatible LCDs
  Copyright (C)2015 Rinky-Dink Electronics, Henning Karlsen. All right reserved
  
  Basic functionality of this library are based on the demo-code provided by
  ITead studio. You can find the latest version of the library at
  http://www.RinkyDinkElectronics.com/

  This library has been made to make it easy to use the basic functions of
  the Nokia 5110 LCD module on an Arduino or a chipKit.

  This library is free software; you can redistribute it and/or
  modify it under the terms of the CC BY-NC-SA 3.0 license.
  Please see the included documents for further information.

  Commercial use of this library requires you to buy a license that
  will allow commercial use. This includes using the library,
  modified or not, as a tool to sell products.

  The license applies to all part of the library including the 
  examples and tools supplied with the library.
*/

#include "OLED1306_Basic.h"
#if defined(__AVR__)
	#include <avr/pgmspace.h>
	#include "hardware/avr/HW_AVR.h"
#elif defined(__PIC32MX__)
	#pragma message("Compiling for PIC32 Architecture...")
	#include "hardware/pic32/HW_PIC32.h"
#elif defined(__arm__)
	#pragma message("Compiling for ARM Architecture...")
	#include "hardware/arm/HW_ARM.h"
#endif

static int skip;    // save some command writes during string printing

#define SSD_ADDRESS                             0x3C
#define SSD1306_128X64				0x40
#define H64_MULTIPLEX_RATIO			0x3F
#define H64_COM_PINS				0x12
//#define H64_BUFFER_SIZE				0x0400
//#define H64_DISPLAY_HEIGHT			0x40

extern void i2start(unsigned char adr);
extern void i2send(unsigned int dat );
extern void i2stop();
extern void i2init();

OLED1306::OLED1306()
{ 
}



void OLED1306::_LCD_Write(unsigned char data, unsigned char mode)
{
static uint8_t cont = LCD_END;       // data continue, avoid unnessary stops on I2C bus

    // mode 0 command, 1 data , 2  end or stop

    if( mode != cont ){                       // changing modes
        if( cont != LCD_END ) i2stop();       // send stop if not already done

        if( mode == LCD_COMMAND ){
          i2start(SSD_ADDRESS);
          i2send(0);              // command mode
        }
        if( mode == LCD_DATA ){
          i2start(SSD_ADDRESS);
          i2send(0x40);           // data mode
        }
    }

    if( mode != LCD_END )  i2send(data);   // skip end command, has dummy data

    cont = mode;                  // continue with what mode we are in

}

    // this function useful only for the 1/2 size 128 by 32 display
/*
void OLED1306::viewPage( int page ){

int startline;

    startline = ( page > 0 ) ? 32 : 0;
  _LCD_Write(SSD1306_SETSTARTLINE | startline, LCD_COMMAND);
}  */

void OLED1306::InitLCD()
{
     i2init();
 
    _LCD_Write(SSD1306_DISPLAY_OFF, LCD_COMMAND);
    _LCD_Write(SSD1306_SET_DISPLAY_CLOCK_DIV_RATIO, LCD_COMMAND);
    _LCD_Write(0x80, LCD_COMMAND);
    _LCD_Write(SSD1306_SET_MULTIPLEX_RATIO, LCD_COMMAND);
    _LCD_Write(H64_MULTIPLEX_RATIO, LCD_COMMAND);			// 0x3F for 128x64, 0x1F for 128x32
    _LCD_Write(SSD1306_SET_DISPLAY_OFFSET, LCD_COMMAND);
    _LCD_Write(0x0, LCD_COMMAND);
    _LCD_Write(SSD1306_SET_START_LINE | 0x0, LCD_COMMAND);
    _LCD_Write(SSD1306_CHARGE_PUMP, LCD_COMMAND);
    _LCD_Write(0x14, LCD_COMMAND);
    _LCD_Write(SSD1306_MEMORY_ADDR_MODE, LCD_COMMAND);
    _LCD_Write(0x00, LCD_COMMAND);
    _LCD_Write(SSD1306_SET_SEGMENT_REMAP | 0x1, LCD_COMMAND);
    _LCD_Write(SSD1306_COM_SCAN_DIR_DEC, LCD_COMMAND);
    _LCD_Write(SSD1306_SET_COM_PINS, LCD_COMMAND);
    _LCD_Write(H64_COM_PINS, LCD_COMMAND);			// 0x12 for 128x64, 0x02 for 128x32
    _LCD_Write(SSD1306_SET_CONTRAST_CONTROL, LCD_COMMAND);
    _LCD_Write(0xCF, LCD_COMMAND);
    _LCD_Write(SSD1306_SET_PRECHARGE_PERIOD, LCD_COMMAND);
    _LCD_Write(0xF1, LCD_COMMAND);
    _LCD_Write(SSD1306_SET_VCOM_DESELECT, LCD_COMMAND);
    _LCD_Write(0x40, LCD_COMMAND);
    _LCD_Write(SSD1306_DISPLAY_ALL_ON_RESUME, LCD_COMMAND);
    _LCD_Write(SSD1306_NORMAL_DISPLAY, LCD_COMMAND);
    _LCD_Write(SSD1306_DISPLAY_ON, LCD_COMMAND);

     //  clrScr();



	cfont.font=0;
	_sleep=false;
	_contrast=0xcf;
}


// not useful for these displays, this is nokia code
/*
void OLED1306::setContrast(int contrast)
{
	if (contrast>0x7F)
		contrast=0x7F;
	if (contrast<0)
		contrast=0;
  _LCD_Write(SSD1306_SETCONTRAST, LCD_COMMAND);                   // 0x81
  _LCD_Write(contrast, LCD_COMMAND);

	_contrast=contrast;
}  */

/****************************************  not used for now

void OLED1306::enableSleep()
{
	_sleep = true;
	_LCD_Write(PCD8544_SETYADDR, LCD_COMMAND);
	_LCD_Write(PCD8544_SETXADDR, LCD_COMMAND);
	for (int b=0; b<504; b++)
		_LCD_Write(0, LCD_DATA);
	_LCD_Write(PCD8544_FUNCTIONSET | PCD8544_POWERDOWN, LCD_COMMAND);
}

void OLED1306::disableSleep()
{
	_LCD_Write(PCD8544_FUNCTIONSET | PCD8544_EXTENDEDINSTRUCTION, LCD_COMMAND);
	_LCD_Write(PCD8544_SETVOP | _contrast, LCD_COMMAND);
	_LCD_Write(PCD8544_SETTEMP | LCD_TEMP, LCD_COMMAND);
	_LCD_Write(PCD8544_SETBIAS | LCD_BIAS, LCD_COMMAND);
	_LCD_Write(PCD8544_FUNCTIONSET, LCD_COMMAND);
	_LCD_Write(PCD8544_DISPLAYCONTROL | PCD8544_DISPLAYNORMAL, LCD_COMMAND);
	_sleep = false;
}
*********************************************/

void OLED1306::clrScr(  ){
int row;

   for( row = 0; row < 8; ++row ) clrRow( row, 0, 127 );

}

// screen positioning for the write and putch functions
void OLED1306::gotoRowCol( int row, int col ){

   //col += 4;      // global x offset for inverted display
   row &= 7;
   col &= 0x7f;

   _LCD_Write(SSD1306_SET_COLUMN_ADDR,LCD_COMMAND);
   _LCD_Write(col,LCD_COMMAND);
   _LCD_Write(127,LCD_COMMAND);
   _LCD_Write(SSD1306_SET_PAGE_ADDR,LCD_COMMAND);
   _LCD_Write(row,LCD_COMMAND);
   _LCD_Write(7,LCD_COMMAND);

}

// write one or more bytes starting at current page pointer position
void OLED1306::write( unsigned char dat, int count ){
int i;

  for( i = 0; i < count; ++i ) _LCD_Write(dat, LCD_DATA );
  _LCD_Write(0,LCD_END); 

}

// print a single character.  Useful when don't need to print a string.
void OLED1306::putch( char dat ){
   
    skip = 1;

    _print_char( dat, 0, 0 );   // print location specified via gotoRowCol before calling 
    
    skip = 0;
}

// print a character array at current page pointer position
void OLED1306::puts( char *p ){
char c;

    while( c = *p++ ) putch(c);

}


void OLED1306::clrRow(int row, int start_x, int end_x)
{

   row &= 7;
   start_x &= 0x7f;
   end_x &= 0x7f;

   _LCD_Write(SSD1306_SET_COLUMN_ADDR,LCD_COMMAND);
   _LCD_Write(start_x,LCD_COMMAND);
   _LCD_Write(127,LCD_COMMAND);
   _LCD_Write(SSD1306_SET_PAGE_ADDR,LCD_COMMAND);
   _LCD_Write(row,LCD_COMMAND);
   _LCD_Write(7,LCD_COMMAND);

   for (int c=start_x; c<=end_x; c++) _LCD_Write(0x00, LCD_DATA);
   _LCD_Write(0,LCD_END);

}

void OLED1306::invert(bool mode)
{
//	if (!_sleep)
//	{
//		if (mode==true)
//			_LCD_Write(PCD8544_DISPLAYCONTROL | PCD8544_DISPLAYINVERTED, LCD_COMMAND);
//		else
//			_LCD_Write(PCD8544_DISPLAYCONTROL | PCD8544_DISPLAYNORMAL, LCD_COMMAND);
//	}
}

void OLED1306::invertText(bool mode)
{
	if (mode==true)
		cfont.inverted=1;
	else
		cfont.inverted=0;
}

// all print functions come here


void OLED1306::print(char *st, int x, int y)
{
	unsigned char ch;
	int stl, row, xp;

	skip = 0;     // need the row and x position code
     if (!_sleep)
	{
		stl = strlen(st);
		if (x == RIGHT)
			x = 128-(stl*cfont.x_size);
		if (x == CENTER)
			x = (128-(stl*cfont.x_size))/2;
		if (x < 0)
			x = 0;

		row = y / 8;
		// xp = x;        //  ????

		for (int cnt=0; cnt<stl; cnt++){
			_print_char(*st++, x + (cnt*(cfont.x_size)), row);
                skip = 1;   // using the auto increment addressing
           }
	}
      skip = 0;
}

void OLED1306::print(String st, int x, int y)
{
	char buf[st.length()+1];

	if (!_sleep)
	{
		st.toCharArray(buf, st.length()+1);
		print(buf, x, y);
	}
}

void OLED1306::printNumI(long num, int x, int y, int length, char filler)
{
	char buf[25];
	char st[27];
	boolean neg=false;
	int c=0, f=0;
  
	if (!_sleep)
	{
		if (num==0)
		{
			if (length!=0)
			{
				for (c=0; c<(length-1); c++)
					st[c]=filler;
				st[c]=48;
				st[c+1]=0;
			}
			else
			{
				st[0]=48;
				st[1]=0;
			}
		}
		else
		{
			if (num<0)
			{
				neg=true;
				num=-num;
			}
	  
			while (num>0)
			{
				buf[c]=48+(num % 10);
				c++;
				num=(num-(num % 10))/10;
			}
			buf[c]=0;
	  
			if (neg)
			{
				st[0]=45;
			}
	  
			if (length>(c+neg))
			{
				for (int i=0; i<(length-c-neg); i++)
				{
					st[i+neg]=filler;
					f++;
				}
			}

			for (int i=0; i<c; i++)
			{
				st[i+neg+f]=buf[c-i-1];
			}
			st[c+neg+f]=0;

		}

		print(st,x,y);
	}
}

void OLED1306::printNumF(double num, byte dec, int x, int y, char divider, int length, char filler)
{
	char st[27];
	boolean neg=false;

	if (!_sleep)
	{
		if (num<0)
			neg = true;

		_convert_float(st, num, length, dec);

		if (divider != '.')
		{
			for (int i=0; i<sizeof(st); i++)
				if (st[i]=='.')
					st[i]=divider;
		}

		if (filler != ' ')
		{
			if (neg)
			{
				st[0]='-';
				for (int i=1; i<sizeof(st); i++)
					if ((st[i]==' ') || (st[i]=='-'))
						st[i]=filler;
			}
			else
			{
				for (int i=0; i<sizeof(st); i++)
					if (st[i]==' ')
						st[i]=filler;
			}
		}

		print(st,x,y);
	}
}

void OLED1306::_print_char(unsigned char c, int x, int row)
{

    // x+= 4;   // offset for difference of 128 and 132 columns
	if (!_sleep)
	{
           if (((x+cfont.x_size)<=132) and (row+(cfont.y_size/8)<=8))
		{
		     for (int rowcnt=0; rowcnt<(cfont.y_size/8); rowcnt++)
			{

                   if( skip == 0 || cfont.y_size > 8 ){  // don't use the auto increment column feature?
                       _LCD_Write(SSD1306_SET_COLUMN_ADDR,LCD_COMMAND);
                       _LCD_Write(x,LCD_COMMAND);
                       _LCD_Write(127,LCD_COMMAND);
                       _LCD_Write(SSD1306_SET_PAGE_ADDR,LCD_COMMAND);
                       _LCD_Write(row+rowcnt,LCD_COMMAND);
                       _LCD_Write(7,LCD_COMMAND);

                //     _LCD_Write( SSD1306_SET_PAGE_ADDR + row + rowcnt, LCD_COMMAND);
                //     _LCD_Write( x & 0xf ,LCD_COMMAND );                // low nibble of column
                //     _LCD_Write( 0x10 | ( x >> 4 ), LCD_COMMAND);      // high nibble
                   }

				int font_idx = ((c - cfont.offset)*(cfont.x_size*(cfont.y_size/8))+4);   //+4;

				for(int cnt=0; cnt<cfont.x_size; cnt++)
				{
					if (cfont.inverted==0)
						_LCD_Write(fontbyte(font_idx+cnt+(rowcnt*cfont.x_size)), LCD_DATA);
					else
						_LCD_Write(~(fontbyte(font_idx+cnt+(rowcnt*cfont.x_size))), LCD_DATA);
				}
			}
			//_LCD_Write(PCD8544_SETYADDR, LCD_COMMAND);
			//_LCD_Write(PCD8544_SETXADDR, LCD_COMMAND);
                       _LCD_Write(0,LCD_END);
		}
	}
}

void OLED1306::setFont(uint8_t* font)
{
	cfont.font=font;
	cfont.x_size=fontbyte(0);
	cfont.y_size=fontbyte(1);
	cfont.offset=fontbyte(2);
	cfont.numchars=fontbyte(3);
	cfont.inverted=0;
}

void OLED1306::drawBitmap(int x, int y, bitmapdatatype bitmap, int sx, int sy)
{
	int starty, rows;
    
	if (!_sleep)
	{
		starty = y / 8;

		if (sy%8==0)
			rows=sy/8;  
		else
			rows=(sy/8)+1;

		for (int cy=0; cy<rows; cy++)
		{

                       _LCD_Write(SSD1306_SET_COLUMN_ADDR,LCD_COMMAND);
                       _LCD_Write(x,LCD_COMMAND);
                       _LCD_Write(127,LCD_COMMAND);
                       _LCD_Write(SSD1306_SET_PAGE_ADDR,LCD_COMMAND);
                       _LCD_Write(starty+cy,LCD_COMMAND);
                       _LCD_Write(7,LCD_COMMAND);
 
                    // _LCD_Write( SSD1306_SET_PAGE_ADDR + starty + cy, LCD_COMMAND);
                    // _LCD_Write( x & 0xf ,LCD_COMMAND );                // low nibble of column
                    // _LCD_Write( 0x10 | ( x >> 4 ), LCD_COMMAND);      // high nibble

		//	_LCD_Write(PCD8544_SETYADDR | (starty+cy), LCD_COMMAND);
		//	_LCD_Write(PCD8544_SETXADDR | x, LCD_COMMAND);
			for(int cx=0; cx<sx; cx++)
				_LCD_Write(bitmapbyte(cx+(cy*sx)), LCD_DATA);
		}      
	//	_LCD_Write(PCD8544_SETYADDR, LCD_COMMAND);
	//	_LCD_Write(PCD8544_SETXADDR, LCD_COMMAND);
        _LCD_Write(0,LCD_END);
	}
}
